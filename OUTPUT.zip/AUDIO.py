# Hide your secret text in wave audio file.
import os
import wave
import tkinter as tk
from tkinter.filedialog import askopenfilename
import shutil
import random
import os
import sys
from PIL import Image, ImageTk
window = tk.Tk()
window.title("AGE INVARIANT FACE RECOGNITION SYSTEM")
window.geometry("500x500")
window.configure(background ="red")


def encrypt():
    window1 = tk.Tk()
    window1.title("AGE INVARIANT FACE RECOGNITION SYSTEM")
    window1.geometry("1000x500")
    window1.configure(background ="darkcyan")
    fileName1 = askopenfilename(initialdir='', title='SELECT AUDIO FOR ENCRYPTION',
                           filetypes=[('audio files', '.wav')])
    lbl=tk.Label(window1,text="Enter the text you want hide..",font=("times",18,"italic"),bg="#a8e0b7")
    lbl.place(x=20,y=70)
    entb_q1=tk.Entry(window1,text="",font=("times",14,"italic"),bg="#a8e0b7")
    entb_q1.place(x=540,y=70)
    lbl=tk.Label(window1,text="Enter the name iof output file in the format (.wav)",font=("times",18,"italic"),bg="#a8e0b7")
    lbl.place(x=20,y=170)
    enty_q1=tk.Entry(window1,text="",font=("times",14,"italic"),bg="#a8e0b7")
    enty_q1.place(x=540,y=170)
    def check1():
            
        af=fileName1
        string=entb_q1.get()
        output=enty_q1.get()
        
        def cls():
          os.system("clear")
        def help():
          print("Hide Your Secret Message in Audio Wave File")

        def em_audio(af, string, output):
            print ("Done...")
            print ("Please wait...")
            waveaudio = wave.open(af, mode='rb')
            frame_bytes = bytearray(list(waveaudio.readframes(waveaudio.getnframes())))
            string = string + int((len(frame_bytes)-(len(string)*8*8))/8) *'#'
            bits = list(map(int, ''.join([bin(ord(i)).lstrip('0b').rjust(8,'0') for i in string])))
            for i, bit in enumerate(bits):
              frame_bytes[i] = (frame_bytes[i] & 254) | bit
            frame_modified = bytes(frame_bytes)
            with wave.open(output, 'wb') as fd:
              fd.setparams(waveaudio.getparams())
              fd.writeframes(frame_modified)
              print('encryption done............')
            waveaudio.close()
            print ("Done...")
        cls()
        try:
          em_audio(af, string, output)
        except:
          print ("Something went wrong!! try again")
          quit('')
    lbl=tk.Button(window1,text="Sumbit",font=("times",18,"italic"),command=check1,bg="#a8e0b7")
    lbl.place(x=300,y=300)
    lbl=tk.Button(window1,text="Close",font=("times",18,"italic"),command=exit,bg="#a8e0b7")
    lbl.place(x=600,y=300)
    window1.mainloop()
def decrypt():
    fileName2 = askopenfilename(initialdir='', title='SELECT AUDIO FOR DECRYPTION ',
                           filetypes=[('audio files', '.wav')])
    def check2():
        af=(fileName2)
        def cls():
           os.system("clear")
        def ex_msg(af):

            print ("Please wait...")
            waveaudio = wave.open(af, mode='rb')
            frame_bytes = bytearray(list(waveaudio.readframes(waveaudio.getnframes())))
            extracted = [frame_bytes[i] & 1 for i in range(len(frame_bytes))]
            string = "".join(chr(int("".join(map(str,extracted[i:i+8])),2)) for i in range(0,len(extracted),8))
            msg = string.split("###")[0]
            print("Your Secret Message is: "+msg)
            waveaudio.close()
            lbl=tk.Label(window,text="your secret message is :"+msg,font=("times",18,"italic"),bg="#a8e0b7")
            lbl.place(x=300,y=200)
        cls()
        try:
          ex_msg(af)
        except:
          print ("Something went wrong!! try again")
          quit('')
    lbl=tk.Button(window,text="upload",font=("times",18,"italic"),command=check2,bg="#a8e0b7")
    lbl.place(x=200,y=20)
buttono = tk.Button(text="ENCRYPT", command = encrypt,height=2,width=10,fg="black",bg="#bef062",font=("times",15,"bold"))
buttono.place(x=100,y=100)

buttonr = tk.Button(text="DECRYPT", command = decrypt,height=2,width=15,fg="black",bg="#bef062",font=("times",15,"bold"))
buttonr.place(x=100,y=200)
window.mainloop()
